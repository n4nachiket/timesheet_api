﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using timesheet.business;
using timesheet.data;
using timesheet.model;

namespace timesheet.api.controllers
{
    [Route("api/v1/employee")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeService employeeService;
        public EmployeeController(IEmployeeService employeeService)
        {
            this.employeeService = employeeService;
        }

        [HttpGet("getall")]
        public IActionResult GetAll(string text)
        {
            var items = this.employeeService.GetEmployees();
            return new ObjectResult(items);
        }

        [HttpGet("getalltasks")]
        public IActionResult GetAllTasks()
        {
            var items = employeeService.GetTasks();
            return new ObjectResult(items);
        }

        [HttpPost]
        public IActionResult PostTimeSheet([FromBody]JToken postData)
        {
            List<TimesheetDay> timesheetDays = JsonConvert.DeserializeObject<List<TimesheetDay>>(postData.ToString());

            bool result = employeeService.PostTimesheet(timesheetDays);

            return new ObjectResult(result);
        }


        [HttpGet("GetTimesheet")]
        public IActionResult GetTimesheet(int employeeId, DateTime startDate, DateTime endDate)
        {
            List<Task> employeeTasks = new List<Task>();

            var timesheetDays = employeeService.GetTimesheetDays().Where(x => x.EmployeeId == employeeId && x.Date >= startDate && x.Date < endDate.AddDays(1).AddSeconds(-1)).ToList();
            var taskIds = timesheetDays.Select(x => x.TaskId).Distinct().ToList();

            var tasks = employeeService.GetTasks().Where(x => taskIds.Contains(x.Id)).ToList();

            foreach (var task in tasks)
            {
                var allWeekDays = new List<TimesheetDay>();

                var date = startDate.Date;

                while (date <= endDate)
                {
                    if (timesheetDays.Any(x => x.Date.Date == date && x.TaskId == task.Id))
                    {
                        allWeekDays.AddRange(timesheetDays.Where(x => x.Date.Date == date && x.TaskId == task.Id).Select(item => new TimesheetDay
                        {
                            Date = item.Date,
                            EmployeeId = item.EmployeeId,
                            Hours = item.Hours,
                            Id = item.Id,
                            TaskId = item.TaskId,
                            Day = item.Date.ToString("dddd")
                        }));
                    }
                    else
                    {
                        allWeekDays.Add(new TimesheetDay
                        {
                            Date = date,
                            Day = date.ToString("dddd"),
                            EmployeeId = employeeId,
                            TaskId = task.Id
                        });
                    }

                    date = date.Date.AddDays(1);
                }

                employeeTasks.Add(new Task
                {
                    Description = task.Description,
                    Id = task.Id,
                    Name = task.Name,
                    TimesheetDays = allWeekDays
                });
            }

            return new ObjectResult(employeeTasks);
        }
    }
}