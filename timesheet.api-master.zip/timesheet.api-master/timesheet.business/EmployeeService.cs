﻿using System;
using System.Collections.Generic;
using System.Linq;
using timesheet.data;
using timesheet.model;

namespace timesheet.business
{
    public class EmployeeService: IEmployeeService
    {
        public TimesheetDb db { get; }
        public EmployeeService(TimesheetDb dbContext)
        {
            this.db = dbContext;
        }

        public List<Employee> GetEmployees()
        {
            var employees = this.db.Employees.ToList();

            foreach (var employee in employees)
            {
                var startDate = GetWeekStartDate();
                var endDate = GetWeekEndDate();
                var timeSheetData = GetTimesheetDays().Where(x => x.EmployeeId == employee.Id && x.Date >= startDate && x.Date < endDate.AddDays(1).AddSeconds(-1)).ToList();
                employee.AverageWeeklyEffort = Decimal.Round((decimal)timeSheetData.Sum(x => x.Hours) / 7, 2);
                employee.TotalWeeklyEffort = Decimal.Round((decimal)timeSheetData.Sum(x => x.Hours),2);
            }

            return employees;
        }

        public IQueryable<Task> GetTasks()
        {
            return db.Tasks;
        }

        public IQueryable<TimesheetDay> GetTimesheetDays()
        {
            return db.TimesheetDays;
        }

        public bool PostTimesheet(List<TimesheetDay> timesheetDays)
        {
            try
            {
                var entriesToRemove = GetTimesheetDays().Where(x => x.EmployeeId == timesheetDays.FirstOrDefault().EmployeeId && timesheetDays.Select(y => y.Date).Contains(x.Date)).ToList();

                if (entriesToRemove.Count > 0)
                {
                    db.TimesheetDays.RemoveRange(entriesToRemove);
                    db.SaveChanges();
                }

                if (timesheetDays.Count > 0)
                {
                    foreach (var day in timesheetDays)
                    {
                        TimesheetDay timesheetDay = new TimesheetDay
                        {
                            Date = day.Date,
                            EmployeeId = day.EmployeeId,
                            Hours = day.Hours,
                            TaskId = day.TaskId
                        };
                        db.Add(timesheetDay);
                        db.SaveChanges();
                    }
                }

                return true;
            }
            catch(Exception ex)
            {
                return false;
            }
        }

        private DateTime GetWeekStartDate()
        {
            return DateTime.Today.AddDays(-1 * (int)DateTime.Today.DayOfWeek);
        }

        private DateTime GetWeekEndDate()
        {
            return GetWeekStartDate().AddDays(6);
        }
    }
}
