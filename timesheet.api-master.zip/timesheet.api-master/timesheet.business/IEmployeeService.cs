﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using timesheet.model;

namespace timesheet.business
{
    public interface IEmployeeService
    {

        List<Employee> GetEmployees();

        IQueryable<Task> GetTasks();

        IQueryable<TimesheetDay> GetTimesheetDays();

        bool PostTimesheet(List<TimesheetDay> tasks);
    }
}
