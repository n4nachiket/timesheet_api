﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace timesheet.model
{
    public class TimesheetDay
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Id { get; set; }

        [NotMapped]
        public string Day { get; set; }

        [Required]
        public DateTime Date { get; set; }

        public float Hours { get; set; }

        [ForeignKey("TaskInfo")]
        [Required]
        public int TaskId { get; set; }

        [ForeignKey("EmployeeInfo")]
        [Required]
        public int EmployeeId { get; set; }
    }
}
