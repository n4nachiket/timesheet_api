﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using timesheet.core.Base;
using timesheet.core.Singleton;
using timesheet.data.Models;
using timesheet.data.Services;
using Task = timesheet.data.Models.Task;

namespace timesheet.wpf.ViewModel
{
    public class TimesheetWindowViewModel : BaseViewModel
    {
        private List<TimesheetDay> timesheetDays;
        private List<Task> timesheetTasks;
        private Week currentWeek;
        private List<Employee> employees;
        private ObservableCollection<string> columnHeaders;
        private DataTable timesheetDataTable;
        private Employee selectedEmployee;
        private List<Task> allTasks;
        private Task newTaskSelectedItem;

        public ICommand AddNewTaskCommand { get; set; }
        public ICommand SaveTimesheetCommand { get; set; }
        public ICommand CloseCommand { get; set; }
        public ICommand PreviousWeekCommand { get; set; }
        public ICommand NextWeekCommand { get; set; }

        public Task NewTaskSelectedItem
        {
            get { return newTaskSelectedItem; }
            set
            {
                newTaskSelectedItem = value;
                NotifyPropertyChanged(nameof(NewTaskSelectedItem));
            }
        }

        public List<Task> AllTasks
        {
            get { return allTasks; }
            set
            {
                allTasks = value;
                NotifyPropertyChanged(nameof(AllTasks));
            }
        }

        public DataTable TimesheetDataTable
        {
            get { return timesheetDataTable; }
            set
            {
                timesheetDataTable = value;
                NotifyPropertyChanged(nameof(TimesheetDataTable));
            }
        }

        public ObservableCollection<string> ColumnHeaders
        {
            get
            {
                return columnHeaders;
            }
            set
            {
                columnHeaders = value;
                NotifyPropertyChanged(nameof(ColumnHeaders));
            }
        }

        public List<Employee> Employees
        {
            get { return employees; }
            set
            {
                employees = value;
                NotifyPropertyChanged(nameof(Employees));
            }
        }

        public List<Task> TimesheetTasks
        {
            get { return timesheetTasks; }
            set
            {
                timesheetTasks = value;
                NotifyPropertyChanged(nameof(TimesheetTasks));
            }
        }

        public Employee SelectedEmployee
        {
            get { return selectedEmployee; }
            set
            {
                if (selectedEmployee != value)
                {
                    selectedEmployee = value;
                    NotifyPropertyChanged(nameof(SelectedEmployee));
                    GetTimesheet();
                }
            }
        }

        public List<TimesheetDay> TimesheetDays 
        {
            get { return timesheetDays; }
            set
            {
                timesheetDays = value;
                NotifyPropertyChanged(nameof(TimesheetDays));
            }
        }

        public Week CurrentWeek
        {
            get
            {
                return currentWeek;
            }
            set
            {
                currentWeek = value;
                NotifyPropertyChanged(nameof(CurrentWeek));
            }
        }

        public TimesheetWindowViewModel()
        {
            TimesheetTasks = new List<data.Models.Task>();
            ColumnHeaders = new ObservableCollection<string>();
            AllTasks = new List<data.Models.Task>();
            TimesheetDataTable = new DataTable();
            AddNewTaskCommand = new RelayCommand<object>(ExecuteNewTaskCommand, CanExecuteNewTaskCommand);
            SaveTimesheetCommand = new RelayCommand<object>(ExecuteSaveTimesheetCommand, CanExecuteSaveTimesheetCommand);
            CloseCommand = new RelayCommand<Window>(ExecuteCloseCommand);
            PreviousWeekCommand = new RelayCommand<object>(ExecutePreviousWeekCommand, CanExecutePreviousWeekCommand);
            NextWeekCommand = new RelayCommand<object>(ExecuteNextWeekCommand, CanExecuteNextWeekCommand);

            GetEmployeesData();
            PopulateData();
        }

        private bool CanExecuteNextWeekCommand(object obj)
        {
            return SelectedEmployee != null;
        }

        private bool CanExecutePreviousWeekCommand(object obj)
        {
            return SelectedEmployee != null;
        }

        private void ExecutePreviousWeekCommand(object obj)
        {
            DateTime endDate = CurrentWeek.StartDate.AddDays(-1);
            DateTime startDate = endDate.AddDays(-6);

            CurrentWeek.StartDate = startDate;
            CurrentWeek.EndDate = endDate;

            GetTimesheet();

            NotifyPropertyChanged(nameof(CurrentWeek));
        }

        private void ExecuteNextWeekCommand(object obj)
        {
            DateTime startDate = CurrentWeek.EndDate.AddDays(1);
            DateTime endDate = startDate.AddDays(6);

            CurrentWeek.StartDate = startDate;
            CurrentWeek.EndDate = endDate;

            GetTimesheet();

            NotifyPropertyChanged(nameof(CurrentWeek));
        }

        private void ExecuteCloseCommand(Window window)
        {
            if (window != null)
            {
                window.Close();
            }
        }

        private bool CanExecuteSaveTimesheetCommand(object obj)
        {
            return SelectedEmployee != null;
        }

        private void ExecuteSaveTimesheetCommand(object obj)
        {
            var employeeService = (EmployeeService)SingletonInstances.GetEmployeeService(typeof(EmployeeService));
            var dataTableValues = GetDataFromDataTable();
            var result = employeeService.UpdateTimesheet(dataTableValues);
        }

        private void ExecuteNewTaskCommand(object obj)
        {
            TimesheetTasks.Add(new data.Models.Task
            {
                Description = NewTaskSelectedItem.Description,
                Id = NewTaskSelectedItem.Id,
                Name = NewTaskSelectedItem.Name,
            });

            LoadDataTable();
        }

        private bool CanExecuteNewTaskCommand(object obj)
        {
            return NewTaskSelectedItem != null && SelectedEmployee != null;
        }

        public void PopulateData()
        {
            CurrentWeek = new Week
            {
                StartDate = DateTime.Today.AddDays(-1 * (int)DateTime.Today.DayOfWeek),
                EndDate = DateTime.Today.AddDays(-1 * (int)DateTime.Today.DayOfWeek).AddDays(6),
            };

            NotifyPropertyChanged(nameof(CurrentWeek));
        }

        private DateTime GetWeekStartDate()
        {
            //return DateTime.Today.AddDays(-1 * (int)DateTime.Today.DayOfWeek);
            return CurrentWeek.StartDate;
        }

        private DateTime GetWeekEndDate()
        {
            return CurrentWeek.EndDate;
            //return GetWeekStartDate().AddDays(6);
        }

        private async void GetTimesheet()
        {
            var employeeService = (EmployeeService)SingletonInstances.GetEmployeeService(typeof(EmployeeService));
            TimesheetTasks = await employeeService.GetTimesheet(SelectedEmployee.Id, CurrentWeek.StartDate, CurrentWeek.EndDate);
            ColumnHeaders.Clear();

            var days = TimesheetTasks.SelectMany(t => t.TimesheetDays).OrderBy(o => o.Date).Select(s => s).Distinct();

            LoadDataTable();
        }

        private List<TimesheetDay> GetDataFromDataTable()
        {
            var timesheetDays = new List<TimesheetDay>();

            foreach(DataRow row in TimesheetDataTable.Rows)
            {
                string task = row["Task Name"].ToString();
                int taskId = AllTasks.FirstOrDefault(x => x.Name == task).Id;
                if (taskId > 0)
                {
                    var startDate = GetWeekStartDate();
                    var endDate = GetWeekEndDate();
                    while (startDate <= endDate)
                    {
                        float hours = float.Parse(row[startDate.ToString("dddd")].ToString());

                        var timesheetDay = new TimesheetDay
                        {
                            TaskId = taskId,
                            Date = startDate,
                            EmployeeId=SelectedEmployee.Id,
                            Hours=hours,
                        };

                        timesheetDays.Add(timesheetDay);

                        startDate = startDate.Date.AddDays(1);
                    }
                    
                }
            }

            return timesheetDays;
        }

        private DateTime GetDateInWeek(string dayName)
        {
            var currentDate = GetWeekStartDate();
            var endDate = GetWeekEndDate();

            while (currentDate <= endDate)
            {
                if (currentDate.DayOfWeek.ToString().ToLower() == dayName.ToLower())
                {
                    return currentDate;
                }

                currentDate = currentDate.Date.AddDays(1);
            }

            return currentDate;
        }

        private void LoadDataTable()
        {
            TimesheetDataTable.Rows.Clear();
            TimesheetDataTable.Columns.Clear();
            TimesheetDataTable.Columns.Add("Task Name");
            foreach (var task in TimesheetTasks)
            {
                var row = TimesheetDataTable.NewRow();
                var items = new ObservableCollection<string>(AllTasks.Select(x => x.Name));

                row["Task Name"] = task.Name;
                TimesheetDataTable.Rows.Add(row);

                if(task.TimesheetDays.Count == 0)
                {
                    DateTime date = GetWeekStartDate();
                    DateTime endDate = GetWeekEndDate();

                    while (date <= endDate)
                    {
                        task.TimesheetDays.Add(new TimesheetDay
                        {
                            Date = date,
                            EmployeeId = SelectedEmployee.Id,
                            TaskId = NewTaskSelectedItem.Id,
                            Day = date.ToString("dddd")
                        });
                        date = date.Date.AddDays(1);
                    }
                }

                foreach (var item in task.TimesheetDays)
                {
                    ColumnHeaders.Add(item.Day);

                    if (!TimesheetDataTable.Columns.Contains(item.Day))
                    {
                        DataColumn dataColumn = new DataColumn();
                        TimesheetDataTable.Columns.Add(item.Day);
                    }

                    row[item.Day] = item.Hours;
                }
            }

            NotifyPropertyChanged(nameof(TimesheetDataTable));
        }

        private async void GetEmployeesData()
        {
            var employeeService = (EmployeeService)SingletonInstances.GetEmployeeService(typeof(EmployeeService));
            Employees = await employeeService.GetEmployees();
            AllTasks = await employeeService.GetTasks();
        }
    }
}
