﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using timesheet.core.Base;
using timesheet.wpf.Views;

namespace timesheet.wpf.ViewModel
{
    public class MainViewModel: BaseViewModel
    {
        public ICommand TimesheetDisplayCommand { get; set; }

        public MainViewModel()
        {
            TimesheetDisplayCommand = new RelayCommand<object>(ExecuteTimesheetDisplayCommand, CanExecuteTimesheetDisplayCommand);
        }

        private bool CanExecuteTimesheetDisplayCommand(object obj)
        {
            return true;
        }

        private void ExecuteTimesheetDisplayCommand(object obj)
        {
            TimesheetWindow timesheet = new TimesheetWindow();
            timesheet.Show();
        }
    }

    public class Command : ICommand
    {
        #region ICommand Members

        public bool CanExecute(object parameter)
        {
            return false;
        }
        public event EventHandler CanExecuteChanged;
        public void Execute(object parameter)
        {

        }
        #endregion
    }
}
