﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using timesheet.data.Models;
using timesheet.wpf.ViewModel;

namespace timesheet.wpf.Controls
{
    public class TimesheetDataGrid : DataGrid
    {
        public ObservableCollection<string> ColumnHeaders
        {
            get { return GetValue(ColumnHeadersProperty) as ObservableCollection<string>; }
            set { SetValue(ColumnHeadersProperty, value); }
        }

        public ObservableCollection<data.Models.Task> TaskMenuOptions
        {
            get { return GetValue(TaskMenuOptionsProperty) as ObservableCollection<data.Models.Task>; }
            set { SetValue(TaskMenuOptionsProperty, value); }
        }

        public static readonly DependencyProperty ColumnHeadersProperty = DependencyProperty.Register("ColumnHeaders", typeof(ObservableCollection<string>), typeof(TimesheetDataGrid), new PropertyMetadata(new PropertyChangedCallback(OnColumnsChanged)));
        public static readonly DependencyProperty TaskMenuOptionsProperty = DependencyProperty.Register("TaskMenuOptions", typeof(ObservableCollection<data.Models.Task>), typeof(TimesheetDataGrid), new PropertyMetadata(new PropertyChangedCallback(OnColumnsChanged)));

        static void OnColumnsChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var dataGrid = d as TimesheetDataGrid;
            dataGrid.Columns.Clear();

            //Add Task Column
            var vm = dataGrid.DataContext as TimesheetWindowViewModel;

            //dataGrid.Columns.Add(new DataGridComboBoxColumn() { Header = "Task Name", SelectedValueBinding=new Binding("Name") { Converter = new TaskComboboxConverter(), ConverterParameter = vm.AllTasks }, DisplayMemberPath="Name", ItemsSource = vm.AllTasks });

            dataGrid.ColumnHeaders.CollectionChanged += (sender, args) =>
            {
                dataGrid.Columns.Clear();

                //dataGrid.Columns.Add(new DataGridComboBoxColumn() { Header = "Task Name", SelectedValueBinding = new Binding("Name") { Converter=new TaskComboboxConverter(), ConverterParameter=vm.AllTasks}, DisplayMemberPath="Name", ItemsSource = vm.AllTasks });

                var headers = sender as ObservableCollection<string>;

                foreach (var value in headers)
                {
                    var column = new DataGridTextColumn() { Header = value, Binding = new Binding("TimesheetDays") { ConverterParameter = value, Converter = new DayHoursConverter() } };
                    dataGrid.Columns.Add(column);
                }
            };

            //Add days Columns
            foreach (var value in dataGrid.ColumnHeaders)
            {
                var column = new DataGridTextColumn() { Header = value, Binding = new Binding("TimesheetDays") { ConverterParameter = value, Converter = new DayHoursConverter() } };
                dataGrid.Columns.Add(column);
            }

        }
    }

    

    public class DayHoursConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var days = value as IEnumerable<TimesheetDay>;
            if (days != null && parameter != null)
            {
                var day = days.FirstOrDefault(s => s.Day.ToLower() == parameter.ToString().ToLower());
                if (day != null)
                    return day.Hours;
                return 0;
            }
            return 0;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
