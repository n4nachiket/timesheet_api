﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using timesheet.data.Contracts;
using timesheet.data.Models;

namespace timesheet.data.Services
{
    public class EmployeeService : IEmployeeService
    {
        private string _baseurl = "https://localhost:44391/api/v1/";
        public EmployeeService()
        {
          
        }
        public async Task<List<Employee>> GetEmployees()
        {
            using (HttpClient client = new HttpClient())
            {
                List<Employee> employees = new List<Employee>();
                HttpResponseMessage response = await client.GetAsync(_baseurl+"/employee/getall");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    employees= JsonConvert.DeserializeObject<List<Employee>>(json);
                }
                return employees;
            }
        }

        public async Task<List<Models.Task>> GetTasks()
        {
            using (HttpClient client = new HttpClient())
            {
                List<Models.Task> tasks = new List<Models.Task>();
                HttpResponseMessage response = await client.GetAsync(_baseurl + "/employee/getalltasks");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    tasks = JsonConvert.DeserializeObject<List<Models.Task>>(json);
                }
                return tasks;
            }
        }

        public async Task<List<Models.Task>> GetTimesheet(int employeeId, DateTime startDate, DateTime endDate)
        {
            using (HttpClient client = new HttpClient())
            {
                List<Models.Task> tasks = new List<Models.Task>();
                string url = string.Format(_baseurl + "/employee/GetTimesheet?employeeId={0}&startDate={1}&endDate={2}", employeeId, startDate.ToShortDateString(), endDate.ToShortDateString());
                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    tasks = JsonConvert.DeserializeObject<List<Models.Task>>(json);
                }
                return tasks;
            }
        }

        public bool UpdateTimesheet(List<Models.TimesheetDay> data)
        {
            try
            {
                List<Models.Task> tasks = new List<Models.Task>();
                string url = _baseurl + "/employee";
                string serializedData = JsonConvert.SerializeObject(data);
                //var content = new StringContent(serializedData.ToString(), Encoding.UTF8, "application/json");
                var httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";

                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    streamWriter.Write(serializedData);
                }

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                }

                if(httpResponse.StatusCode == HttpStatusCode.OK)
                {
                    return true;
                }

                return false;
            }
            catch(Exception ex)
            {
                return false;
            }
        }
    }
}
