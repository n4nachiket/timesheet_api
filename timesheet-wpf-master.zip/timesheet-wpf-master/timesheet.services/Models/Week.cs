﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace timesheet.data.Models
{
    public class Week
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public string Name { get { return string.Format("{0} - {1}", StartDate.ToShortDateString(), EndDate.ToShortDateString()); } }
    }
}
