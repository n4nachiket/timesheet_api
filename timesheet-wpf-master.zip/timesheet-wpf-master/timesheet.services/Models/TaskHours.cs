﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace timesheet.data.Models
{
    public class TaskHours
    {
        public int TaskId { get; set; }
        public string TaskName { get; set; }
        public int Hours { get; set; }
    }
}
