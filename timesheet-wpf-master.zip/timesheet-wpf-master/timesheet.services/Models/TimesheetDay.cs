﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace timesheet.data.Models
{
    public class TimesheetDay
    {
        public int Id { get; set; }

        public string Day { get; set; }

        public DateTime Date { get; set; }

        public float Hours { get; set; }

        public int TaskId { get; set; }

        public int EmployeeId { get; set; }
    }
}
