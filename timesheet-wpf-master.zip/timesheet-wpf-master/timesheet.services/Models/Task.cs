﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace timesheet.data.Models
{
    public class Task
    {
        public Task()
        {
            TimesheetDays = new ObservableCollection<TimesheetDay>();
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public ObservableCollection<TimesheetDay> TimesheetDays { get; set; }
    }
}
