﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using timesheet.data.Models;

namespace timesheet.data.Contracts
{
    public interface IEmployeeService
    {
        Task<List<Employee>> GetEmployees();
        Task<List<Models.Task>> GetTasks();
        Task<List<Models.Task>> GetTimesheet(int employeeId, DateTime startDate, DateTime endDate);
        bool UpdateTimesheet(List<Models.TimesheetDay> data);
    }
}
